/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package objAutomata;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.awt.geom.Arc2D;
import java.awt.geom.QuadCurve2D;
import javax.swing.JPanel;

/**
 *
 * @author Pedro Ibañez
 */
public class Grafos extends JPanel{
    
    public int[] posicion={0,0,0,0};//guarda la coordenada inicial y final del grafo
    
        
        public void linea(Graphics g){
            Graphics2D g2d=(Graphics2D) g;
            g2d.drawLine(0, 0, 522, 608);
        }
        
        public void inicio(Graphics g){//dibuja el inicio del grafo 
            Graphics2D g2d=(Graphics2D) g;
            int px=10;//posición inicial en x
            int py=35;//posición inicial en y
            
            g2d.setStroke(new BasicStroke(2));//define el ancho de las lineas                         
            g2d.drawLine(px, py, px+25, py);//dibuja la línea de la flecha de inicio
            
            int[] xPoints={px+25,px+35,px+25};
            int[] yPoints={py-10,py,py+10};            
            g2d.drawPolygon(xPoints, yPoints, 3);//dibuja la punta de la flecha de inicio
            
            g2d.drawString("inicio", px-5, py-3);//dibuja la palabra inicio 
            
            int[] pfinal={px, py, px+35, py};//compila la posición inicial y final del grafo
            posicion=pfinal;//declara la posición del principio a la izquierda y el final a la derecha
        }
        
        public void estado(Graphics g, int[] pinicio, String nestado){//dibuja un estado en el extremo de una trancisión
            Graphics2D g2d=(Graphics2D) g;
            int px=pinicio[2];//posición inicial en x
            int py=pinicio[3];//posición inicial en y
            
            g2d.setColor(Color.blue);//define el color de linea
            g2d.setStroke(new BasicStroke(2));//define el ancho de las lineas
            
            g2d.drawOval(px, py-10, 60, 20);//dibuja circunferencia
            g2d.drawString(nestado, px+10, py+5);//dibuja el nombre del estado
            
            int[] pfinal={px, py, px+60, py};//compila la posición inicial y final del grafo
            posicion=pfinal;//retorna la posición del final a la derecha                        
        }
        
        public void trancisicion(Graphics g, int[] pinicio, int lng, int angulo, String ntrancision){
            Graphics2D g2d=(Graphics2D) g;
            AffineTransform oldform=g2d.getTransform();//guarda el angulo 0
            int pix=pinicio[2];//posición del final del estado anterior
            int piy=pinicio[3];
            
            double angle=angulo*Math.PI/180;//convierte el ángulo en radianes
            int pfx=pinicio[2]+ (int) Math.round(lng * Math.sin(angle));//posición final de la trancision, inicio del estado siguiente
            int pfy=pinicio[3]+ (int) Math.round(lng * Math.cos(angle));
            
            g2d.setStroke(new BasicStroke(2));//define el ancho de las lineas
            g2d.drawLine(pix, piy, pfx, pfy);//dibuja la línea de la flecha
            
            int x=pinicio[2]+ (int) Math.round(Math.round(lng/2) * Math.sin(angle));
            int y=pinicio[3]+ (int) Math.round(Math.round(lng/2) * Math.cos(angle));
            g2d.drawString(ntrancision, x-20, y-2);//dibuja el nombre de la trancisión estado
            
            int[] xPoints={pfx-10,pfx,pfx-10};
            int[] yPoints={pfy-10,pfy,pfy+10};            
            g2d.drawPolygon(xPoints, yPoints, 3);//dibuja la punta de la flecha
            g2d.rotate(angle, (xPoints[0]+xPoints[1]+xPoints[2])/3, (yPoints[0]+yPoints[1]+yPoints[2])/3);//gira la punta de la flecha hacia el siguiente estado            
            
            int pfin[]={pix, piy, pfx, pfy};//retorna la posición del inicio y final de la trancisión
            posicion=pfin;
            g2d.setTransform(oldform);//reinicia el objeto g2d
        }
        
        public void loop(Graphics g, int[] pinicio, String ntrancision){
            Graphics2D g2d=(Graphics2D) g;
            AffineTransform oldform=g2d.getTransform();//guarda el angulo 0
            int px=pinicio[0];//posición inicial en x
            int py=pinicio[1];//posición inicial en y
            
            g2d.setColor(Color.blue);//define el color de linea
            g2d.setStroke(new BasicStroke(2));//define el ancho de las lineas
            
            QuadCurve2D q=new QuadCurve2D.Float();
            q.setCurve(px, py, px+30, py-50, px+60, py);//define un arco spline 
            g2d.draw(q);//dibuja el arco 
                      
            g2d.drawString(ntrancision, px, py-25);//dibuja el nombre de la trancisión estado
                                    
            int pfin[]={pinicio[0], pinicio[1], pinicio[0], pinicio[1]};//retorna la posición del inicio y final de la trancisión
            posicion=pfin;
            g2d.setTransform(oldform);//reinicia el objeto g2d
            
        }
        
        public void reset(Graphics g, int[] pinicio, String ntrancision){
            Graphics2D g2d=(Graphics2D) g;
            AffineTransform oldform=g2d.getTransform();//guarda el angulo 0
            int px=pinicio[2];//posición inicial en x
            int py=pinicio[3];//posición inicial en y
            
            g2d.setColor(Color.red);//define el color de linea
            g2d.setStroke(new BasicStroke(2));//define el ancho de las lineas
            
            g2d.setStroke(new BasicStroke(3));//define el ancho de las lineas
            g2d.drawLine(px, py, 45, 35);//dibuja la línea del último estado al inicio
            
            g2d.drawString(ntrancision, px, py-25);//dibuja el nombre de la trancisión estado
                                    
            int pfin[]={pinicio[0], pinicio[1], pinicio[0], pinicio[1]};//retorna la posición del inicio y final de la trancisión
            posicion=pfin;
            g2d.setTransform(oldform);//reinicia el objeto g2d
            
        }
}

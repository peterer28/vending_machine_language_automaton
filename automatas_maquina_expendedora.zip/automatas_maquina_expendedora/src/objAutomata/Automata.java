/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package objAutomata;

import java.awt.Graphics;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 *
 * @author Pedro Ibañez
 */
public class Automata {
    public Graphics g;//objeto grafics requerido por Grafos
    Grafos gr=new Grafos();//instancia de clase Grafos para dibujar 
    public JTextArea jt=new JTextArea();
    public JTextField jf=new JTextField();
    public String cmb;
    public double cambio;
    public String w;
    public String drv;
    
    public Automata(){//inicializador de variables 
    w="";
    cambio=0;    
}
    public void inicio(String cadena){//recibe la cadena para empezar análisis         
        //JOptionPane.showMessageDialog(null, cadena);//solicita al usuario cadena para iniciar
        
        if(cadena==null){
            cadena="vacio";
        }
        
        //String word[]=cadena.split(" ",2);//extrae el primer caracter de la cadena que pertenece al lenguaje, almacena el resto en un arreglo
        cmb=cadena;
        drv="inicio->"+"\n";//escribe inicio
        jt.append(drv+"\n");

        gr.inicio(g);//dibuja inicio del grafo          
        q0c00(cadena);//envía la cadena al primer estado
        
        /*switch (word[0]){//selecciona el siguiente estado según el caracter leido 
            case "Q0.25":
                q0c25(word[1]);//envía el resto de la cadena al siguiente estado
                break;
            case "Q1.00":
                q1c00(word[1]);//envía el resto de la cadena al siguiente estado
                break;
            case "abrt":
                JOptionPane.showMessageDialog(null, "ingrese monedas");//solicita al usuario cadena para iniciar 
                break;
            case "select":
                JOptionPane.showMessageDialog(null, "ingrese monedas");//solicita al usuario cadena para iniciar 
                break;
            default:
                JOptionPane.showMessageDialog(null, "ingrese monedas para iniciar");//solicita al usuario cadena para iniciar 
                break;
        }*/
        
        
    }
    
    public void q0c00(String cadena){
        JOptionPane.showMessageDialog(null, cadena);
         if(cadena==null){
            cadena="vacio";
        }
         
        String word[]=cadena.split(" ",2);//extrae el primer caracter de la cadena que pertenece al lenguaje, almacena el resto en un arreglo
        drv=drv+"->"+word[0]+"->Q0C00"+"\n";
        jt.append(drv+"\n");
        
        gr.estado(g, gr.posicion, "Q0C00");//dibuja estado actual en el grafo
        
        
        switch (word[0]){//selecciona el siguiente estado según el caracter leido 
            case "Q1.00":
                gr.trancisicion(g, gr.posicion, 94,322, word[0]);//dibuja trancisión al siguente estado
                q1c00(word[1]);
                break;
            case "Q0.25":
                gr.trancisicion(g, gr.posicion, 60, 90, word[0]);//dibuja trancisión al siguente estado
                q0c25(word[1]);
                break;
            case "abrt":
                JOptionPane.showMessageDialog(null, "reciba su dinero");//solicita al usuario cadena para iniciar 
                jf.setText(cmb);
                inicio(w=null);
                break;
            case "select":
                
                break;
            default:
                JOptionPane.showMessageDialog(null, "fondos insuficientes, reciba su dinero");//solicita al usuario cadena para iniciar
                jf.setText(cmb);
                break;    
        } 
    }
    
    public void q0c25(String cadena){
        JOptionPane.showMessageDialog(null, cadena);
         if(cadena==null){
            cadena="vacio";
        }
         
        String word[]=cadena.split(" ",2);//extrae el primer caracter de la cadena que pertenece al lenguaje, almacena el resto en un arreglo
        drv=drv+"->"+word[0]+"->Q0C25"+"\n";
        jt.append(drv+"\n");
        
        gr.estado(g, gr.posicion, "Q0C25");//dibuja estado actual en el grafo
        
        
        switch (word[0]){//selecciona el siguiente estado según el caracter leido 
            case "Q1.00":
                gr.trancisicion(g, gr.posicion, 94,322, word[0]);//dibuja trancisión al siguente estado
                q1c25(word[1]);
                break;
            case "Q0.25":
                gr.trancisicion(g, gr.posicion, 60, 90, word[0]);//dibuja trancisión al siguente estado
                q0c50(word[1]);
                break;
            case "abrt":
                JOptionPane.showMessageDialog(null, "reciba su dinero");//solicita al usuario cadena para iniciar 
                jf.setText(cmb);
                inicio(w=null);
                break;
            case "select":
                
                break;
            default:
                JOptionPane.showMessageDialog(null, "fondos insuficientes, reciba su dinero");//solicita al usuario cadena para iniciar 
                jf.setText(cmb);
                break;    
        } 
    }
    
    public void q0c50(String cadena){
        JOptionPane.showMessageDialog(null, cadena);
         if(cadena==null){
            cadena="vacio";
        }
         
        String word[]=cadena.split(" ",2);//extrae el primer caracter de la cadena que pertenece al lenguaje, almacena el resto en un arreglo
        drv=drv+"->"+word[0]+"->Q0C50"+"\n";
        jt.append(drv+"\n");
        
        gr.estado(g, gr.posicion, "Q0C50");//dibuja estado actual en el grafo
        
        switch (word[0]){//selecciona el siguiente estado según el caracter leido 
            case "Q1.00":
                gr.trancisicion(g, gr.posicion, 94,322, word[0]);//dibuja trancisión al siguente estado
                q1c50(word[1]);
                break;
            case "Q0.25":
                gr.trancisicion(g, gr.posicion, 60, 90, word[0]);//dibuja trancisión al siguente estado
                q0c75(word[1]);
                break;
            case "abrt":
                JOptionPane.showMessageDialog(null, "reciba su dinero");//solicita al usuario cadena para iniciar
                jf.setText(cmb);
                inicio(w=null);
                break;
            case "select":
                
                break;
            default:
                JOptionPane.showMessageDialog(null, "fondos insuficientes, reciba su dinero");//solicita al usuario cadena para iniciar 
                jf.setText(cmb);
                break;    
        } 
    }
    
    
    
    public void q0c75(String cadena){
        JOptionPane.showMessageDialog(null, cadena);
         if(cadena==null){
            cadena="vacio";
        }
         
        String word[]=cadena.split(" ",2);//extrae el primer caracter de la cadena que pertenece al lenguaje, almacena el resto en un arreglo
        drv=drv+"->"+word[0]+"->Q0C75"+"\n";
        jt.append(drv+"\n");
        
        gr.estado(g, gr.posicion, "Q0C75");//dibuja estado actual en el grafo
        
        switch (word[0]){//selecciona el siguiente estado según el caracter leido 
            case "Q1.00":
                gr.trancisicion(g, gr.posicion, 94,322, word[0]);//dibuja trancisión al siguente estado
                q1c75(word[1]);
                break;
            case "Q0.25":
                gr.trancisicion(g, gr.posicion, 425, 280, word[0]);//dibuja trancisión al siguente estado
                q1c00(word[1]);
                break;
            case "abrt":
                JOptionPane.showMessageDialog(null, "reciba su dinero");//solicita al usuario cadena para iniciar 
                jf.setText(cmb);
                inicio(w=null);
                break;
            case "select":
                
                break;
            default:
                JOptionPane.showMessageDialog(null, "fondos insuficientes, reciba su dinero");//solicita al usuario cadena para iniciar
                jf.setText(cmb);
                break;    
        } 
    }
    
        public void q1c00(String cadena){
        JOptionPane.showMessageDialog(null, cadena+String.valueOf(gr.posicion[2])+" "+String.valueOf(gr.posicion[3]));
         if(cadena==null){
            cadena="vacio";
        }
         
        String word[]=cadena.split(" ",2);//extrae el primer caracter de la cadena que pertenece al lenguaje, almacena el resto
        drv=drv+"->"+word[0]+"->Q1C00"+"\n";
        jt.append(drv+"\n");
        
        gr.estado(g, gr.posicion, "Q1C00");//dibuja estado actual en el grafo
        
        switch (word[0]){//selecciona el siguiente estado según el caracter leido 
            case "Q1.00":
                gr.trancisicion(g, gr.posicion, 94,322, word[0]);//dibuja trancisión al siguente estado
                q2c00(word[1]);
                break;
            case "Q0.25":
                gr.trancisicion(g, gr.posicion, 60, 90, word[0]);//dibuja trancisión al siguente estado
                q1c25(word[1]);
                break;
            case "abrt":
                JOptionPane.showMessageDialog(null, "reciba su dinero");//solicita al usuario cadena para iniciar 
                jf.setText(cmb);
                inicio(w=null);
                break;
            case "select":
                
                break;
            default:
                JOptionPane.showMessageDialog(null, "fondos insuficientes, reciba su dinero");//solicita al usuario cadena para iniciar 
                jf.setText(cmb);
                break;    
        } 
    }
        
        public void q1c25(String cadena){
        JOptionPane.showMessageDialog(null, cadena);
         if(cadena==null){
            cadena="vacio";
        }
         
        String word[]=cadena.split(" ",2);//extrae el primer caracter de la cadena que pertenece al lenguaje, almacena el resto
        drv=drv+"->"+word[0]+"->Q1C25"+"\n";
        jt.append(drv+"\n");
        
        gr.estado(g, gr.posicion, "Q1C25");//dibuja estado actual en el grafo
        
        switch (word[0]){//selecciona el siguiente estado según el caracter leido 
            case "Q1.00":
                gr.trancisicion(g, gr.posicion, 94,322, word[0]);//dibuja trancisión al siguente estado
                q2c25(word[1]);
                break;
            case "Q0.25":
                gr.trancisicion(g, gr.posicion, 60, 90, word[0]);//dibuja trancisión al siguente estado
                q1c50(word[1]);
                break;
            case "abrt":
                JOptionPane.showMessageDialog(null, "reciba su dinero");//solicita al usuario cadena para iniciar 
                jf.setText(cmb);
                inicio(w=null);
                break;
            case "select":
                
                break;
            default:
                JOptionPane.showMessageDialog(null, "fondos insuficientes, reciba su dinero");//solicita al usuario cadena para iniciar 
                jf.setText(cmb);
                break;    
        } 
    }
        
        public void q1c50(String cadena){
        JOptionPane.showMessageDialog(null, cadena);
         if(cadena==null){
            cadena="vacio";
        }
         
        String word[]=cadena.split(" ",2);//extrae el primer caracter de la cadena que pertenece al lenguaje, almacena el resto
        drv=drv+"->"+word[0]+"->Q1C50"+"\n";
        jt.append(drv+"\n");
        
        gr.estado(g, gr.posicion, "Q1C50");//dibuja estado actual en el grafo
        
        switch (word[0]){//selecciona el siguiente estado según el caracter leido 
            case "Q1.00":
                gr.trancisicion(g, gr.posicion, 94,322, word[0]);//dibuja trancisión al siguente estado
                q2c50(word[1]);
                break;
            case "Q0.25":
                gr.trancisicion(g, gr.posicion, 60, 90, word[0]);//dibuja trancisión al siguente estado
                q1c75(word[1]);
                break;
            case "abrt":
                JOptionPane.showMessageDialog(null, "reciba su dinero");//solicita al usuario cadena para iniciar 
                jf.setText(cmb);
                inicio(w=null);
                break;
            case "select":
                
                break;
            default:
                JOptionPane.showMessageDialog(null, "fondos insuficientes, reciba su dinero");//solicita al usuario cadena para iniciar 
                jf.setText(cmb);
                break;    
        } 
    }
        
        public void q1c75(String cadena){
        JOptionPane.showMessageDialog(null, cadena);
         if(cadena==null){
            cadena="vacio";
        }
         
        String word[]=cadena.split(" ",2);//extrae el primer caracter de la cadena que pertenece al lenguaje, almacena el resto
        drv=drv+"->"+word[0]+"->Q1C75"+"\n";
        jt.append(drv+"\n");
        
        gr.estado(g, gr.posicion, "Q1C75");//dibuja estado actual en el grafo
        
        switch (word[0]){//selecciona el siguiente estado según el caracter leido 
            case "Q1.00":
                gr.trancisicion(g, gr.posicion, 94,322, word[0]);//dibuja trancisión al siguente estado
                q2c75(word[1]);
                break;
            case "Q0.25":
                gr.trancisicion(g, gr.posicion, 425, 280, word[0]);//dibuja trancisión al siguente estado
                q2c00(word[1]);
                break;
            case "abrt":
                JOptionPane.showMessageDialog(null, "reciba su dinero");//solicita al usuario cadena para iniciar
                jf.setText(cmb);
                inicio(w=null);
                break;
            case "select":
                
                break;
            default:
                JOptionPane.showMessageDialog(null, "fondos insuficientes, reciba su dinero");//solicita al usuario cadena para iniciar 
                jf.setText(cmb);
                break;    
        } 
    }
        public void q2c00(String cadena){
        JOptionPane.showMessageDialog(null, cadena);
         if(cadena==null){
            cadena="vacio";
        }
         
        String word[]=cadena.split(" ",2);//extrae el primer caracter de la cadena que pertenece al lenguaje, almacena el resto
        drv=drv+"->"+word[0]+"->Q2C00"+"\n";
        jt.append(drv+"\n");
        
        gr.estado(g, gr.posicion, "Q2C00");//dibuja estado actual en el grafo
        
        switch (word[0]){//selecciona el siguiente estado según el caracter leido 
            case "Q1.00":
                gr.trancisicion(g, gr.posicion, 94,322, word[0]);//dibuja trancisión al siguente estado
                q3c00(word[1]);
                break;
            case "Q0.25":
                gr.trancisicion(g, gr.posicion, 60, 90, word[0]);//dibuja trancisión al siguente estado
                q2c25(word[1]);
                break;
            case "abrt":
                JOptionPane.showMessageDialog(null, "reciba su dinero");//solicita al usuario cadena para iniciar 
                jf.setText(cmb);
                inicio(w=null);
                break;
            case "select":
                
                break;
            default:
                JOptionPane.showMessageDialog(null, "fondos insuficientes, reciba su dinero");//solicita al usuario cadena para iniciar 
                jf.setText(cmb);
                break;    
        } 
    }
        
        public void q2c25(String cadena){
        JOptionPane.showMessageDialog(null, cadena);
         if(cadena==null){
            cadena="vacio";
        }
         
        String word[]=cadena.split(" ",2);//extrae el primer caracter de la cadena que pertenece al lenguaje, almacena el resto
        drv=drv+"->"+word[0]+"->Q2C25"+"\n";
        jt.append(drv+"\n");
        
        gr.estado(g, gr.posicion, "Q2C25");//dibuja estado actual en el grafo
        
        switch (word[0]){//selecciona el siguiente estado según el caracter leido 
            case "Q1.00":
                gr.trancisicion(g, gr.posicion, 94,322, word[0]);//dibuja trancisión al siguente estado
                q3c25(word[1]);
                break;
            case "Q0.25":
                gr.trancisicion(g, gr.posicion, 60, 90, word[0]);//dibuja trancisión al siguente estado
                q2c50(word[1]);
                break;
            case "abrt":
                JOptionPane.showMessageDialog(null, "reciba su dinero");//solicita al usuario cadena para iniciar 
                jf.setText(cmb);
                inicio(w=null);
                break;
            case "select":
                
                break;
            default:
                JOptionPane.showMessageDialog(null, "fondos insuficientes, reciba su dinero");//solicita al usuario cadena para iniciar 
                jf.setText(cmb);
                break;    
        } 
    }
        
        public void q2c50(String cadena){
        JOptionPane.showMessageDialog(null, cadena);
         if(cadena==null){
            cadena="vacio";
        }
         
        String word[]=cadena.split(" ",2);//extrae el primer caracter de la cadena que pertenece al lenguaje, almacena el resto
        drv=drv+"->"+word[0]+"->Q2C50"+"\n";
        jt.append(drv+"\n");
        
        gr.estado(g, gr.posicion, "Q2C50");//dibuja estado actual en el grafo
        
        switch (word[0]){//selecciona el siguiente estado según el caracter leido 
            case "Q1.00":
                gr.trancisicion(g, gr.posicion, 94,322, word[0]);//dibuja trancisión al siguente estado
                q3c50(word[1]);
                break;
            case "Q0.25":
                gr.trancisicion(g, gr.posicion, 60, 90, word[0]);//dibuja trancisión al siguente estado
                q2c75(word[1]);
                break;
            case "abrt":
                JOptionPane.showMessageDialog(null, "reciba su dinero");//solicita al usuario cadena para iniciar 
                jf.setText(cmb);
                inicio(w=null);
                break;
            case "select":
                
                break;
            default:
                JOptionPane.showMessageDialog(null, "fondos insuficientes, reciba su dinero");//solicita al usuario cadena para iniciar 
                jf.setText(cmb);
                break;    
        } 
    }
        
        public void q2c75(String cadena){
        JOptionPane.showMessageDialog(null, cadena);
         if(cadena==null){
            cadena="vacio";
        }
         
        String word[]=cadena.split(" ",2);//extrae el primer caracter de la cadena que pertenece al lenguaje, almacena el resto
        drv=drv+"->"+word[0]+"->Q2C75"+"\n";
        jt.append(drv+"\n");
        
        gr.estado(g, gr.posicion, "Q2C75");//dibuja estado actual en el grafo
        
        switch (word[0]){//selecciona el siguiente estado según el caracter leido 
            case "Q1.00":
                gr.trancisicion(g, gr.posicion, 94,322, word[0]);//dibuja trancisión al siguente estado
                q3c75(word[1]);
                break;
            case "Q0.25":
                gr.trancisicion(g, gr.posicion, 425, 280, word[0]);//dibuja trancisión al siguente estado
                q3c00(word[1]);
                break;
            case "abrt":
                JOptionPane.showMessageDialog(null, "reciba su dinero");//solicita al usuario cadena para iniciar 
                jf.setText(cmb);
                inicio(w=null);
                break;
            case "select":
                
                break;
            default:
                JOptionPane.showMessageDialog(null, "fondos insuficientes, reciba su dinero");//solicita al usuario cadena para iniciar 
                jf.setText(cmb);
                break;    
        } 
    }
        
        public void q3c00(String cadena){            
        JOptionPane.showMessageDialog(null, cadena);
         if(cadena==null){
            cadena="vacio";
        }
         
        String word[]=cadena.split(" ",2);//extrae el primer caracter de la cadena que pertenece al lenguaje, almacena el resto
        drv=drv+"->"+word[0]+"->Q3C00"+"\n";
        jt.append(drv+"\n");
        
        gr.estado(g, gr.posicion, "Q3C00");//dibuja estado actual en el grafo
        
        switch (word[0]){//selecciona el siguiente estado según el caracter leido 
            case "Q1.00":
                gr.trancisicion(g, gr.posicion, 94,322, word[0]);//dibuja trancisión al siguente estado
                q4c00(word[1]);
                break;
            case "Q0.25":
                gr.trancisicion(g, gr.posicion, 60, 90, word[0]);//dibuja trancisión al siguente estado
                q3c25(word[1]);
                break;
            case "abrt":
                JOptionPane.showMessageDialog(null, "reciba su dinero");//solicita al usuario cadena para iniciar 
                jf.setText(cmb);
                inicio(w=null);
                break;
            case "select":
                
                break;
            default:
                JOptionPane.showMessageDialog(null, "fondos insuficientes, reciba su dinero");//solicita al usuario cadena para iniciar 
                jf.setText(cmb);
                break;    
        } 
    }
        
        public void q3c25(String cadena){
        JOptionPane.showMessageDialog(null, cadena);
         if(cadena==null){
            cadena="vacio";
        }
         
        String word[]=cadena.split(" ",2);//extrae el primer caracter de la cadena que pertenece al lenguaje, almacena el resto
        drv=drv+"->"+word[0]+"->Q3C25"+"\n";
        jt.append(drv+"\n");
        
        gr.estado(g, gr.posicion, "Q3C25");//dibuja estado actual en el grafo
        
        switch (word[0]){//selecciona el siguiente estado según el caracter leido 
            case "Q1.00":
                gr.trancisicion(g, gr.posicion, 94,322, word[0]);//dibuja trancisión al siguente estado
                q4c25(word[1]);
                break;
            case "Q0.25":
                gr.trancisicion(g, gr.posicion, 60, 90, word[0]);//dibuja trancisión al siguente estado
                q3c50(word[1]);
                break;
            case "abrt":
                JOptionPane.showMessageDialog(null, "reciba su dinero");//solicita al usuario cadena para iniciar
                jf.setText(cmb);
                inicio(w=null);
                break;
            case "select":
                
                break;
            default:
                JOptionPane.showMessageDialog(null, "fondos insuficientes, reciba su dinero");//solicita al usuario cadena para iniciar
                jf.setText(cmb);
                break;    
        } 
    }
        
        public void q3c50(String cadena){
        JOptionPane.showMessageDialog(null, cadena);
         if(cadena==null){
            cadena="vacio";
        }
         
        //String word[]=cadena.split(" ",2);//extrae el primer caracter de la cadena que pertenece al lenguaje, almacena el resto
        drv=drv+"->"+cadena+"->Q3C50"+"\n";
        jt.append(drv+"\n");
        
        gr.estado(g, gr.posicion, "Q3C50");//dibuja estado actual en el grafo        
        
        switch (cadena){//selecciona el siguiente estado según el caracter leido             
            case "abrt":
                JOptionPane.showMessageDialog(null, "reciba su dinero");//solicita al usuario cadena para iniciar 
                jf.setText(cmb);
                inicio(w=null);
                break;
            default:
                gr.trancisicion(g, gr.posicion, 94, 322, cadena);//dibuja trancisión al siguente estado
                dispensa(cadena);
                break;
        }                
    }
        
        public void q3c75(String cadena){
        JOptionPane.showMessageDialog(null, cadena);
         if(cadena==null){
            cadena="vacio";
        }
         
        //String word[]=cadena.split(" ",2);//extrae el primer caracter de la cadena que pertenece al lenguaje, almacena el resto
        drv=drv+"->"+cadena+"->Q3C75"+"\n";
        jt.append(drv+"\n");
        
        gr.estado(g, gr.posicion, "Q3C75");//dibuja estado actual en el grafo
        
        switch (cadena){//selecciona el siguiente estado según el caracter leido             
            case "abrt":
                JOptionPane.showMessageDialog(null, "reciba su dinero");//solicita al usuario cadena para iniciar
                jf.setText(cmb);
                inicio(w=null);
                break;
            default:
                dispensa(cadena);
                jf.setText("Q0.25");;
                break;
        }                
    }
        
        public void q4c00(String cadena){
        JOptionPane.showMessageDialog(null, cadena);
         if(cadena==null){
            cadena="vacio";
        }
         
        //String word[]=cadena.split(" ",2);//extrae el primer caracter de la cadena que pertenece al lenguaje, almacena el resto
        drv=drv+"->"+cadena+"->Q4C00"+"\n";
        jt.append(drv+"\n");
        
        gr.estado(g, gr.posicion, "Q4C00");//dibuja estado actual en el grafo
        
        switch (cadena){//selecciona el siguiente estado según el caracter leido             
            case "abrt":
                JOptionPane.showMessageDialog(null, "reciba su dinero");//solicita al usuario cadena para iniciar 
                jf.setText(cmb);
                inicio(w=null);
                break;
            default:
                dispensa(cadena);
                jf.setText("Q0.50");;
                break;
        }
    }
        
        public void q4c25(String cadena){        
         if(cadena==null){
            cadena="vacio";
        }
         
        //String word[]=cadena.split(" ",2);//extrae el primer caracter de la cadena que pertenece al lenguaje, almacena el resto
        drv=drv+"->"+cadena+"->Q4C25"+"\n";
        jt.append(drv+"\n");
        
        gr.estado(g, gr.posicion, "Q4C25");//dibuja estado actual en el grafo
        
        switch (cadena){//selecciona el siguiente estado según el caracter leido             
            case "abrt":
                JOptionPane.showMessageDialog(null, "reciba su dinero");//solicita al usuario cadena para iniciar
                jf.setText(cmb);
                inicio(w=null);
                break;
            default:
                dispensa(cadena);
                jf.setText("Q0.75");;
                break;
        }
    }
        
        public void dispensa(String cadena){ 
         JOptionPane.showMessageDialog(null, cadena+String.valueOf(gr.posicion[2])+" "+String.valueOf(gr.posicion[3]));
         if(cadena==null){
            cadena="vacio";
        }
         
        //String word[]=cadena.split(" ",2);//extrae el primer caracter de la cadena que pertenece al lenguaje, almacena el resto
        drv=drv+"->"+cadena+"->Dispensa"+"\n";
        jt.append(drv+"\n");
        
        gr.estado(g, gr.posicion, "Dispensa");//dibuja estado actual en el grafo
                
        switch (cadena){//selecciona el siguiente estado según el caracter leido             
            case "abrt":
                JOptionPane.showMessageDialog(null, "reciba su dinero");//solicita al usuario cadena para iniciar 
                jf.setText(cmb);
                inicio(w=null);
                break;
            case "select":
                JOptionPane.showMessageDialog(null, "reciba su gaseosa");//máquina dispensa gaseosa seleccionada
                inicio(w=null);//reinicia la máquina
                break;                
            default:
                cmb=cadena;
                JOptionPane.showMessageDialog(null, "reciba su gaseosa");//máquina dispensa gaseosa seleccionada
                inicio(w=null);
                break;
         
    }
    
}
        
}
